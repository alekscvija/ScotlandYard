package uk.ac.bris.cs.scotlandyard.model;

/**
 * Transports on the map of the Scotland Yard game
 */
public enum Transport {
	Taxi, Bus, Underground, Boat
}
